import React, { useState } from 'react';

const StarIcon = ({ filled }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill={filled ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={filled ? "text-yellow-400" : "text-gray-300"}
    >
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
);

const Movie = ({ movie, onRate }) => {
    const [rating, setRating] = useState(0);
    const [hoveredRating, setHoveredRating] = useState(0);
    const [isRated, setIsRated] = useState(false);

    const handleRate = () => {
        if (rating > 0) {
            onRate(movie.id, rating);
            setIsRated(true);
            setTimeout(() => {
                setRating(0);
                setIsRated(false);
            }, 2000);
        }
    };

    const renderStars = () => {
        return Array(5).fill(0).map((_, index) => {
            const starNumber = index + 1;
            const isFilled = hoveredRating ? starNumber <= hoveredRating : starNumber <= rating;
            
            return (
                <button
                    key={index}
                    className={`transition-all duration-200 transform ${
                        isFilled ? 'scale-110' : 'scale-100'
                    } hover:scale-110`}
                    onMouseEnter={() => setHoveredRating(starNumber)}
                    onMouseLeave={() => setHoveredRating(0)}
                    onClick={() => setRating(starNumber)}
                >
                    <StarIcon filled={isFilled} />
                </button>
            );
        });
    };

    return (
        <div className="bg-white rounded-lg shadow-md p-6 mb-4 transition-all duration-300 hover:shadow-lg">
            <h3 className="text-xl font-semibold mb-2">{movie.title}</h3>
            <p className="text-gray-600 mb-4">{movie.description}</p>
            
            <div className="space-y-4">
                <div className="flex items-center gap-2">
                    {renderStars()}
                    <span className="ml-2 text-sm text-gray-500">
                        {rating > 0 ? `${rating} out of 5` : 'Rate this movie'}
                    </span>
                </div>
                
                <button
                    onClick={handleRate}
                    disabled={rating === 0 || isRated}
                    className={`w-full py-2 px-4 rounded-md transition-all duration-300 ${
                        rating === 0
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : isRated
                            ? 'bg-green-500 text-white cursor-not-allowed'
                            : 'bg-blue-500 hover:bg-blue-600 text-white'
                    }`}
                >
                    {isRated ? 'Thanks for rating!' : 'Submit Rating'}
                </button>
            </div>
        </div>
    );
};

export default Movie;