// src/components/RatingStars.jsx
import React from 'react';
import './styles.module.css'; // Import your CSS module

const RatingStars = ({ rating, onRate }) => {
    const stars = [1, 2, 3, 4, 5];

    return (
        <div className="rating-stars">
            {stars.map((star) => (
                <span
                    key={star}
                    className={`star ${star <= rating ? 'filled' : ''}`}
                    onClick={() => onRate(star)}
                >
                    ★
                </span>
            ))}
        </div>
    );
};

export default RatingStars;