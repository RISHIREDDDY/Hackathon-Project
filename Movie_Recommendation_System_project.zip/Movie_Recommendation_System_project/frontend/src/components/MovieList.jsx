import React from 'react';
import Movie from './Movie';

const MovieList = ({ movies, onRate }) => {
    return (
        <div className="max-w-4xl mx-auto p-6">
            <h2 className="text-3xl font-bold mb-8 text-gray-800">
                Movie List
            </h2>
            <div className="grid gap-6 grid-cols-1">
                {movies.map(movie => (
                    <Movie 
                        key={movie.id} 
                        movie={movie} 
                        onRate={onRate} 
                    />
                ))}
            </div>
        </div>
    );
};

export default MovieList;