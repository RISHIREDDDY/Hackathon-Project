import React, { useEffect, useState } from 'react';
import MovieList from './components/MovieList';
import axios from 'axios';

const App = () => {
    const [movies, setMovies] = useState([]);
    const [ratings, setRatings] = useState({});

    useEffect(() => {
        const fetchMovies = async () => {
            const response = await axios.get('http://localhost:5000/movies');
            setMovies(response.data);
        };
        fetchMovies();
    }, []);

    const handleRate = async (movieId, rating) => {
        await axios.post('http://localhost:5000/rate', { movieId, rating });
        setRatings((prevRatings) => ({
            ...prevRatings,
            [movieId]: rating,
        }));
    };

    return (
        <div>
            <h1>Movie Recommendation System</h1>
            <MovieList movies={movies} onRate={handleRate} />
            <h2>Your Ratings</h2>
            <ul>
                {Object.entries(ratings).map(([movieId, rating]) => (
                    <li key={movieId}>
                        Movie ID: {movieId}, Rating: {rating}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default App;