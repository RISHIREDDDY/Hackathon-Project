// backend/server.js
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

// MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Replace with your MySQL username
    password: '1234', // Replace with your MySQL password
    database: 'movie_ratings_db',
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Database');
});

// Get movies
app.get('/movies', (req, res) => {
    const movies = [
        { id: 1, title: 'Inception', description: 'A mind-bending thriller ' },
        { id: 2, title: 'Interstellar', description: 'A journey through space and time' },
        { id: 3, title: 'The Matrix', description: 'A hacker discovers the truth about his reality' },
    ];
    res.json(movies);
});

// Submit rating
app.post('/rate', (req, res) => {
    const { movieId, rating } = req.body;
    const query = 'INSERT INTO ratings (movie_id, rating) VALUES (?, ?)';
    db.query(query, [movieId, rating], (err, result) => {
        if (err) throw err;
        res.json({ message: 'Rating submitted successfully!' });
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});