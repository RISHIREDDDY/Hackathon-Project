// src/App.jsx

import React from 'react';
import Home from './Home';
import './index.css';

const App = () => {
  return <Home />;
};

export default App;
